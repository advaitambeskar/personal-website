# personal-website
Responsive Personal website

IDEA
-----
* Clean, responsive design
* Simple + low loading time